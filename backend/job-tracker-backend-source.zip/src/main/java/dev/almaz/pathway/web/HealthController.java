package dev.almaz.pathway.web;
import dev.almaz.pathway.service.AiService;import org.springframework.web.bind.annotation.*;import java.util.Map;
@RestController @RequestMapping("/api") public class HealthController{private final AiService ai;public HealthController(AiService ai){this.ai=ai;}@GetMapping("/health") public Map<String,Object> health(){return Map.of("status","ok","application","job-application-tracker","aiConfigured",ai.isConfigured());}}
