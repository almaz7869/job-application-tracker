package dev.almaz.pathway.web;
import dev.almaz.pathway.data.ApplicationRepository;
import dev.almaz.pathway.domain.Application;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import jakarta.validation.Valid;
import java.util.*;

@RestController @RequestMapping("/api/applications") @Validated
public class ApplicationController {
    private final ApplicationRepository repo;
    public ApplicationController(ApplicationRepository r){repo=r;}
    private String owner(){return SecurityContextHolder.getContext().getAuthentication().getName();}
    @GetMapping public List<Application> list(){return repo.findByOwnerOrderByIdDesc(owner());}
    @PostMapping public Application create(@RequestBody @Valid Application value){value.setOwner(owner());return repo.save(value);}
    @PatchMapping("/{id}") public Application update(@PathVariable Long id,@RequestBody Map<String,String> body){
        Application a=repo.findById(id).filter(x->x.getOwner().equals(owner())).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));
        if(body.containsKey("status"))a.setStatus(body.get("status"));
        if(body.containsKey("nextStep"))a.setNextStep(body.get("nextStep"));
        if(body.containsKey("notes"))a.setNotes(body.get("notes"));
        return repo.save(a);
    }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id){var a=repo.findById(id).filter(x->x.getOwner().equals(owner())).orElseThrow(()->new ResponseStatusException(HttpStatus.NOT_FOUND));repo.delete(a);}
}
